
var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "rathu",
  password: "9194",
  database: "grocy"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected To Mysql");
  var sql = "INSERT INTO customers (name, address) VALUES ('Muthu', 'Cuddalore')";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("one Row inserted");
  });
});

